"""
Sample Plugin for Services AI
A demonstration plugin for the Services AI pluggy-based plugin system
"""

__version__ = '1.0.0'
